import tensorflow as tf
import tensorflow.keras.layers as layers


class ActorModel(tf.keras.Model):
    def __init__(self, state_size, action_size):
        super(__class__, self).__init__()
        self.dense1 = layers.Dense(512, activation='relu')
        self.out = layers.Dense(action_size, activation='softmax')
        self.build(input_shape=(None, state_size))
    
    def call(self, x):
        x = self.dense1(x)
        policy = self.out(x)
        return policy

    
class CriticModel(tf.keras.Model):
    def __init__(self, state_size):
        super(__class__, self).__init__()
        self.dense1 = layers.Dense(512, activation='relu')
        self.dense2 = layers.Dense(512, activation='relu')
        self.out = layers.Dense(1)
        self.build(input_shape=(None, state_size))
    
    def call(self, x):
        x = self.dense1(x)
        x = self.dense2(x)
        value = self.out(x)
        return value
