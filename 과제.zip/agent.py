import tensorflow as tf
import tensorflow.keras.optimizers as optimizers
import numpy as np

from model import ActorModel, CriticModel


class A2CAgent:
    def __init__(self, state_size, action_size, step_size=None):
        self.state_size = state_size
        self.action_size = action_size
        self.discount_factor = 0.99
        self.learning_rate = 0.0001
        self.step_size = step_size
        self.memory = []
        self.actor_model = ActorModel(self.state_size, self.action_size)
        self.critic_model = CriticModel(self.state_size)
        self.optimizer = optimizers.Adam(lr=self.learning_rate)
        
    def get_action(self, state):
        policy = self.actor_model(state.reshape(1, -1))
        policy = np.array(policy[0])
        return np.random.choice(self.action_size, 1, p=policy)[0]
    
    def calculate_G(self, rewards, next_state):
        G = np.zeros_like(rewards, dtype='float32')
        next_value = 0
        if next_state is not None:
            next_value = self.critic_model(next_state.reshape(1, -1))[0]
            next_value = next_value.numpy()
        for t in reversed(range(0, len(rewards))):
            value = rewards[t] + self.discount_factor * next_value
            G[t] = value
            next_value = value
        return G
    
    def train(self, state, action, reward, next_state, done):
        # append to step memory
        self.memory.append((state, action, reward))
        
        if done:
            states = np.array([item[0] for item in self.memory])
            actions = np.array([item[1] for item in self.memory])
            rewards = np.array([item[2] for item in self.memory])
            targets = self.calculate_G(rewards, None)
            self.memory = []
        elif self.step_size and (len(self.memory) >= self.step_size):
            states = np.array([item[0] for item in self.memory])
            actions = np.array([item[1] for item in self.memory])
            rewards = np.array([item[2] for item in self.memory])
            targets = self.calculate_G(rewards, next_state)
            self.memory = []
        else:
            return
        
        critic_model_params = self.critic_model.trainable_variables
        actor_model_params = self.actor_model.trainable_variables
        
        with tf.GradientTape(persistent=True) as tape:
            policy = self.actor_model(states)
            values = self.critic_model(states)
            advantages = targets - values

            one_hot_actions = tf.one_hot(actions, self.action_size, axis=1)
            action_probs = tf.reduce_sum(one_hot_actions * policy, axis=1, keepdims=True)
            cross_entropy = -tf.math.log(action_probs)

            critic_loss = tf.reduce_mean(tf.square(advantages))
            actor_loss = 0.1 * tf.reduce_sum(cross_entropy * advantages)
            
        critic_grads = tape.gradient(critic_loss, critic_model_params)
        actor_grads = tape.gradient(actor_loss, actor_model_params)
        del tape
        
        self.optimizer.apply_gradients(zip(actor_grads, actor_model_params))
        self.optimizer.apply_gradients(zip(critic_grads, critic_model_params))
